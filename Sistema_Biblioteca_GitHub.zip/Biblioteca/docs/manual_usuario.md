# Manual de usuario
## Sistema de Administración de Biblioteca

**Equipo:** Eduardo Sosa, Antonio Cerón y Juan Flores.

### 1. Requisitos e inicio
Se necesita Python 3.8 o superior. No es necesario instalar paquetes adicionales.

1. Descarga o clona el repositorio.
2. Abre una terminal en la carpeta `Biblioteca`.
3. Ejecuta `python src/main.py`. Si el comando no funciona, prueba `python3 src/main.py`.
4. Aparecerá el menú principal.

### 2. Opciones del menú

- **1. Registrar libro:** captura título y autor. El año y el ISBN/código son opcionales. El sistema asigna un ID automáticamente.
- **2. Consultar catálogo:** muestra todos los libros, su ID y su estado.
- **3. Buscar por título o autor:** escribe una palabra o parte del nombre para localizar coincidencias.
- **4. Registrar préstamo:** introduce el ID de un libro disponible y el nombre de quien lo recibe. No se puede prestar un libro que ya esté prestado.
- **5. Registrar devolución:** introduce el ID del libro prestado. El sistema lo marca como disponible.
- **6. Mostrar disponibles y prestados:** presenta los libros separados por estado.
- **0. Guardar y salir:** guarda los cambios y termina el programa.

### 3. Almacenamiento de información
Los datos se guardan automáticamente en `data/libros.json` después de registrar libros, préstamos o devoluciones. También se guardan al salir. No elimines ese archivo si deseas conservar el catálogo.

### 4. Recomendaciones
- Conserva el ID de cada libro para registrar préstamos y devoluciones.
- Escribe correctamente el nombre de la persona que recibe el libro.
- No cierres la terminal antes de seleccionar la opción **0. Guardar y salir**.
- Si vas a compartir el proyecto, incluye la carpeta `data` para conservar los registros.

### 5. Solución de problemas
- **Python no se reconoce:** instala Python y verifica que esté agregado al PATH.
- **No aparecen libros:** revisa que `data/libros.json` exista y contenga datos.
- **ID incorrecto:** consulta primero el catálogo para confirmar el número.
