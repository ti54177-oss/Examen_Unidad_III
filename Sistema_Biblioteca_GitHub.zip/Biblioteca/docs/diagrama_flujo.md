# Diagrama de flujo general

```mermaid
flowchart TD
    A([Inicio]) --> B[Cargar libros desde libros.json]
    B --> C[Mostrar menú principal]
    C --> D{Seleccionar opción}
    D -->|1| E[Registrar libro]
    D -->|2| F[Consultar catálogo]
    D -->|3| G[Buscar por título o autor]
    D -->|4| H[Registrar préstamo]
    D -->|5| I[Registrar devolución]
    D -->|6| J[Mostrar disponibles y prestados]
    E --> K[Guardar información]
    H --> K
    I --> K
    F --> C
    G --> C
    J --> C
    K --> C
    D -->|0| L[Guardar información]
    L --> M([Fin])
    D -->|Otra opción| N[Mostrar mensaje de error]
    N --> C
```

El sistema carga los datos al iniciar. Después presenta un menú que permite ejecutar las operaciones. Los cambios realizados se guardan en el archivo JSON.
