"""Funciones para gestionar préstamos y devoluciones."""


def _buscar_por_id(libros, id_libro):
    for libro in libros:
        if libro["id"] == id_libro:
            return libro
    return None


def prestar_libro(libros):
    print("\n--- Registrar préstamo ---")
    try:
        id_libro = int(input("ID del libro: ").strip())
    except ValueError:
        print("El ID debe ser un número.")
        return

    libro = _buscar_por_id(libros, id_libro)
    if libro is None:
        print("No existe un libro con ese ID.")
    elif not libro["disponible"]:
        print("El libro ya está prestado.")
    else:
        nombre = input("Nombre de la persona que recibe el libro: ").strip()
        if not nombre:
            print("El nombre es obligatorio.")
            return
        libro["disponible"] = False
        libro["prestado_a"] = nombre
        print(f'Préstamo registrado: "{libro["titulo"]}" para {nombre}.')


def devolver_libro(libros):
    print("\n--- Registrar devolución ---")
    try:
        id_libro = int(input("ID del libro: ").strip())
    except ValueError:
        print("El ID debe ser un número.")
        return

    libro = _buscar_por_id(libros, id_libro)
    if libro is None:
        print("No existe un libro con ese ID.")
    elif libro["disponible"]:
        print("Ese libro ya aparece como disponible.")
    else:
        persona = libro["prestado_a"]
        libro["disponible"] = True
        libro["prestado_a"] = ""
        print(f'El libro "{libro["titulo"]}" fue devuelto por {persona}.')
