"""Funciones para registrar, consultar y buscar libros."""


def registrar_libro(libros):
    print("\n--- Registrar libro ---")
    titulo = input("Título: ").strip()
    autor = input("Autor: ").strip()
    anio_txt = input("Año de publicación: ").strip()
    isbn = input("ISBN o código (opcional): ").strip()

    if not titulo or not autor:
        print("El título y el autor son obligatorios.")
        return

    try:
        anio = int(anio_txt) if anio_txt else None
        if anio is not None and (anio < 0 or anio > 2100):
            raise ValueError
    except ValueError:
        print("El año debe ser un número válido.")
        return

    siguiente_id = max((libro["id"] for libro in libros), default=0) + 1
    libros.append({
        "id": siguiente_id,
        "titulo": titulo,
        "autor": autor,
        "anio": anio,
        "isbn": isbn,
        "disponible": True,
        "prestado_a": ""
    })
    print(f"Libro registrado correctamente con ID {siguiente_id}.")


def listar_libros(libros):
    print("\n--- Catálogo de libros ---")
    if not libros:
        print("Todavía no hay libros registrados.")
        return

    for libro in libros:
        estado = "Disponible" if libro["disponible"] else f"Prestado a {libro['prestado_a']}"
        anio = libro["anio"] if libro["anio"] is not None else "No indicado"
        print(f'ID: {libro["id"]} | {libro["titulo"]} | {libro["autor"]} | '
              f'Año: {anio} | Estado: {estado}')


def buscar_libros(libros):
    termino = input("\nEscribe el título o autor que deseas buscar: ").strip().casefold()
    if not termino:
        print("Escribe un término para realizar la búsqueda.")
        return

    encontrados = [
        libro for libro in libros
        if termino in libro["titulo"].casefold() or termino in libro["autor"].casefold()
    ]

    if not encontrados:
        print("No se encontraron coincidencias.")
        return

    print(f"Se encontraron {len(encontrados)} resultado(s):")
    for libro in encontrados:
        estado = "Disponible" if libro["disponible"] else "Prestado"
        print(f'ID: {libro["id"]} | {libro["titulo"]} | {libro["autor"]} | {estado}')


def mostrar_disponibilidad(libros):
    disponibles = [libro for libro in libros if libro["disponible"]]
    prestados = [libro for libro in libros if not libro["disponible"]]

    print("\n--- Libros disponibles ---")
    if disponibles:
        for libro in disponibles:
            print(f'ID {libro["id"]}: {libro["titulo"]} - {libro["autor"]}')
    else:
        print("No hay libros disponibles.")

    print("\n--- Libros prestados ---")
    if prestados:
        for libro in prestados:
            print(f'ID {libro["id"]}: {libro["titulo"]} - Prestado a {libro["prestado_a"]}')
    else:
        print("No hay libros prestados.")
