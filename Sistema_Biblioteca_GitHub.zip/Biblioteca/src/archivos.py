"""Lectura y escritura de los datos de la biblioteca en formato JSON."""
import json
import os


def cargar_libros(ruta):
    """Carga los libros guardados; devuelve una lista vacía si el archivo no existe."""
    if not os.path.exists(ruta):
        return []
    try:
        with open(ruta, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        print("Aviso: no se pudieron leer los datos. Se iniciará un catálogo vacío.")
        return []


def guardar_libros(ruta, libros):
    """Guarda la lista completa de libros en un archivo JSON."""
    carpeta = os.path.dirname(ruta)
    if carpeta:
        os.makedirs(carpeta, exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as archivo:
        json.dump(libros, archivo, ensure_ascii=False, indent=4)
