"""Punto de entrada del Sistema de Administración de Biblioteca."""
from libros import registrar_libro, listar_libros, buscar_libros, mostrar_disponibilidad
from prestamos import prestar_libro, devolver_libro
from archivos import cargar_libros, guardar_libros

ARCHIVO_DATOS = "data/libros.json"


def mostrar_menu():
    print("\n========== BIBLIOTECA ==========")
    print("1. Registrar libro")
    print("2. Consultar catálogo")
    print("3. Buscar por título o autor")
    print("4. Registrar préstamo")
    print("5. Registrar devolución")
    print("6. Mostrar disponibles y prestados")
    print("0. Guardar y salir")
    return input("Selecciona una opción: ").strip()


def main():
    libros = cargar_libros(ARCHIVO_DATOS)
    print(f"Se cargaron {len(libros)} libro(s).")

    while True:
        opcion = mostrar_menu()

        if opcion == "1":
            registrar_libro(libros)
            guardar_libros(ARCHIVO_DATOS, libros)
        elif opcion == "2":
            listar_libros(libros)
        elif opcion == "3":
            buscar_libros(libros)
        elif opcion == "4":
            prestar_libro(libros)
            guardar_libros(ARCHIVO_DATOS, libros)
        elif opcion == "5":
            devolver_libro(libros)
            guardar_libros(ARCHIVO_DATOS, libros)
        elif opcion == "6":
            mostrar_disponibilidad(libros)
        elif opcion == "0":
            guardar_libros(ARCHIVO_DATOS, libros)
            print("Información guardada. ¡Hasta pronto!")
            break
        else:
            print("Opción no válida. Intenta nuevamente.")


if __name__ == "__main__":
    main()
