# Sistema de Administración de Biblioteca

**Integrantes**
- Eduardo Sosa
- Antonio Cerón
- Juan Flores

Aplicación de consola desarrollada en Python para administrar el catálogo de una pequeña biblioteca.

## Funcionalidades
- Registrar libros con título, autor, año e ISBN/código.
- Consultar el catálogo.
- Buscar por título o autor.
- Registrar préstamos por ID y nombre del usuario.
- Registrar devoluciones.
- Mostrar libros disponibles y prestados.
- Guardar automáticamente la información en `data/libros.json`.

## Requisitos
- Python 3.8 o superior.
- No requiere instalar librerías externas.

## Cómo ejecutar
Desde la carpeta principal del proyecto:

```bash
python src/main.py
```

En algunos equipos puede ser necesario usar `python3` en lugar de `python`.

## Estructura
```text
Biblioteca/
├── src/
│   ├── main.py
│   ├── libros.py
│   ├── prestamos.py
│   └── archivos.py
├── data/
│   └── libros.json
├── docs/
│   ├── diagrama_flujo.md
│   └── manual_usuario.md
├── .gitignore
└── README.md
```

## Flujo de trabajo sugerido en GitHub
1. Crear el repositorio `sistema-biblioteca`.
2. Subir la rama `main` con la estructura inicial.
3. Cada integrante crea una rama para su tarea, por ejemplo `feature/catalogo`, `feature/prestamos` o `feature/documentacion`.
4. Realizar commits pequeños y descriptivos.
5. Abrir Pull Requests hacia `main`.
6. Un compañero revisa cada Pull Request antes de integrarlo.
7. Resolver conflictos y volver a solicitar revisión si es necesario.

**Meta del equipo:** cada integrante debe crear al menos 3 Pull Requests revisados por otro integrante.
